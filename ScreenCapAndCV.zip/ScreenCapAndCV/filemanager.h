#pragma once
#include <iostream>
#include <map>
#include <vector>


void FindFile(std::string strFilePath, std::vector<std::string>& m_arrFilePath);
CString GetFilePath(std::string strPathBuf);

std::string GetFilePathStr(std::string strPath);